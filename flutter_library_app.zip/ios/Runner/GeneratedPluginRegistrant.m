//
//  Generated file. Do not edit.
//

#import "GeneratedPluginRegistrant.h"

#if __has_include(<pushpole/PushPolePlugin.h>)
#import <pushpole/PushPolePlugin.h>
#else
@import pushpole;
#endif

@implementation GeneratedPluginRegistrant

+ (void)registerWithRegistry:(NSObject<FlutterPluginRegistry>*)registry {
  [PushPolePlugin registerWithRegistrar:[registry registrarForPlugin:@"PushPolePlugin"]];
}

@end
