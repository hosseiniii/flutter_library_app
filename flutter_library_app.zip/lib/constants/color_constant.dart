import 'dart:ui';

const kMainColor = Color(0xFFFFAAA5);
const kBackgroundColor = Color(0xFFFAFAFA);
const kBlackColor = Color(0xFF121212);
const kGreyColor = Color(0xFFAAAAAA);
const kLightGreyColor = Color(0xFFF4F4F4);
const kWhiteColor = Color(0xFFFFFFFF);